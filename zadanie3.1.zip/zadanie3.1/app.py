from flask import Flask, render_template, redirect
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = 'Norbert Gierczak'
bootstrap = Bootstrap(app)

class NameForm(FlaskForm):
    name = StringField('Podaj swoje imię', validators=[DataRequired()])
    submit = SubmitField('Wyślij')

@app.route('/', methods=['POST', 'GET'])
def index():
    name = None
    form = NameForm()
    if form.validate_on_submit():
        name = form.name.data = ''
        print(form.name.date)
    return render_template('index.html', title='Formularz WTF', form=form, name=name)

@app.route('/form', methods=['POST', 'GET'])
def form():
    return render_template('user.html', title='Formularz WTF', form=form, name=name)

if __name__ == '__main__':
    app.run(debug=True)